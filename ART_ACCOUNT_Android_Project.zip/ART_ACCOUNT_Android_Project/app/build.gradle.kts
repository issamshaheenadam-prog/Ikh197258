plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.artaccount.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.artaccount.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 11
        versionName = "1.0.0-beta11"
    }
}
